// ESTROGA, Ezra Anaeurin A.
// May 24, 2024
// CMSC 28 | K-2L

#ifndef PRODUCTINVENTORY_H
#define PRODUCTINVENTORY_H

#include <string>

class Product {
protected:
    std::string name;
    std::string brand;
    double price;
    int quantity;
    std::string description;
    std::string size;
    std::string color;
    std::string category;
    std::string model;
    float warranty; // in years
    std::string technicalSpecifications;
    std::string material;

public:
    // Constructor
    Product(std::string name, std::string brand, double price, int quantity, std::string description,
            std::string size, std::string color, std::string category, std::string model,
            float warranty, std::string technicalSpecifications, std::string material);

    // Getters
    std::string getName() const;
    std::string getBrand() const;
    double getPrice() const;
    int getQuantity() const;
    std::string getDescription() const;
    std::string getSize() const;
    std::string getColor() const;
    std::string getCategory() const;
    std::string getModel() const;
    float getWarranty() const;
    std::string getTechnicalSpecifications() const;
    std::string getMaterial() const;

    // Setters
    void setName(const std::string &name);
    void setBrand(const std::string &brand);
    void setPrice(double price);
    void setQuantity(int quantity);
    void setDescription(const std::string &description);
    void setSize(const std::string &size);
    void setColor(const std::string &color);
    void setCategory(const std::string &category);
    void setModel(const std::string &model);
    void setWarranty(float warranty);
    void setTechnicalSpecifications(const std::string &technicalSpecifications);
    void setMaterial(const std::string &material);
};

class Clothing : public Product {
public:
    Clothing(std::string name, std::string brand, double price, int quantity, std::string description,
             std::string size, std::string color, std::string category, std::string model,
             float warranty, std::string technicalSpecifications, std::string material);
};

class Electronics : public Product {
public:
    Electronics(std::string name, std::string brand, double price, int quantity, std::string description,
                std::string size, std::string color, std::string category, std::string model,
                float warranty, std::string technicalSpecifications, std::string material);
};

#endif // PRODUCTINVENTORY_H

