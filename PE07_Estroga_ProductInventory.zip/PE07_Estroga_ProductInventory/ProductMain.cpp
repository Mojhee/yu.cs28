// ESTROGA, Ezra Anaeurin A.
// May 24, 2024
// CMSC 28 | K-2L

#include "ProductInventory.h"
#include <iostream>

// Product class implementation
Product::Product(std::string name, std::string brand, double price, int quantity, std::string description,
                 std::string size, std::string color, std::string category, std::string model,
                 float warranty, std::string technicalSpecifications, std::string material)
    : name(name), brand(brand), price(price), quantity(quantity), description(description),
      size(size), color(color), category(category), model(model), warranty(warranty),
      technicalSpecifications(technicalSpecifications), material(material) {}

// Getters
std::string Product::getName() const { return name; }
std::string Product::getBrand() const { return brand; }
double Product::getPrice() const { return price; }
int Product::getQuantity() const { return quantity; }
std::string Product::getDescription() const { return description; }
std::string Product::getSize() const { return size; }
std::string Product::getColor() const { return color; }
std::string Product::getCategory() const { return category; }
std::string Product::getModel() const { return model; }
float Product::getWarranty() const { return warranty; }
std::string Product::getTechnicalSpecifications() const { return technicalSpecifications; }
std::string Product::getMaterial() const { return material; }

// Setters
void Product::setName(const std::string &name) { this->name = name; }
void Product::setBrand(const std::string &brand) { this->brand = brand; }
void Product::setPrice(double price) { this->price = price; }
void Product::setQuantity(int quantity) { this->quantity = quantity; }
void Product::setDescription(const std::string &description) { this->description = description; }
void Product::setSize(const std::string &size) { this->size = size; }
void Product::setColor(const std::string &color) { this->color = color; }
void Product::setCategory(const std::string &category) { this->category = category; }
void Product::setModel(const std::string &model) { this->model = model; }
void Product::setWarranty(float warranty) { this->warranty = warranty; }
void Product::setTechnicalSpecifications(const std::string &technicalSpecifications) { this->technicalSpecifications = technicalSpecifications; }
void Product::setMaterial(const std::string &material) { this->material = material; }

// Clothing class implementation
Clothing::Clothing(std::string name, std::string brand, double price, int quantity, std::string description,
                   std::string size, std::string color, std::string category, std::string model,
                   float warranty, std::string technicalSpecifications, std::string material)
    : Product(name, brand, price, quantity, description, size, color, category, model, warranty, technicalSpecifications, material) {}

// Electronics class implementation
Electronics::Electronics(std::string name, std::string brand, double price, int quantity, std::string description,
                         std::string size, std::string color, std::string category, std::string model,
                         float warranty, std::string technicalSpecifications, std::string material)
    : Product(name, brand, price, quantity, description, size, color, category, model, warranty, technicalSpecifications, material) {}

// Main function
int main() {
    // Creating instances of Clothing and Electronics with predefined details
    std::cout << "This is an example of instances for Clothing and Electronics." << std::endl;
    
    Clothing shirt("T-Shirt", "BrandA", 19.99, 100, "Comfortable cotton t-shirt", "L", "Red", "Clothing", "ModelA", 0.5, "", "Cotton");
    Electronics phone("Smartphone", "BrandB", 699.99, 50, "Latest smartphone with high-end specs", "", "Black", "Electronics", "ModelB", 2.0, "64GB storage, 4GB RAM", "");

    // Printing predefined details
    std::cout << "\nPredefined Clothing Item: " << shirt.getName() << "\nBrand: " << shirt.getBrand() << "\nPrice: " << shirt.getPrice() << "\nQuantity: " << shirt.getQuantity() << "\nDescription: " << shirt.getDescription() << "\nSize: " << shirt.getSize() << "\nColor: " << shirt.getColor() << "\nCategory: " << shirt.getCategory() << "\nModel: " << shirt.getModel() << "\nWarranty: " << shirt.getWarranty() << " years \nMaterial: " << shirt.getMaterial() << std::endl;

    std::cout << "\nPredefined Electronics Item: " << phone.getName() << "\nBrand: " << phone.getBrand() << "\nPrice: " << phone.getPrice() << "\nQuantity: " << phone.getQuantity() << "\nDescription: " << phone.getDescription() << "\nColor: " << phone.getColor() << "\nCategory: " << phone.getCategory() << "\nModel: " << phone.getModel() << "\nWarranty: " << phone.getWarranty() << " years \nTechnical Specifications: " << phone.getTechnicalSpecifications() << std::endl;

    std::cout << "\n\n\nNow it's your turn to create instances for Clothing and Electronics" << std::endl;
    // Prompting user to input details for Clothing
    std::string name, brand, description, size, color, category, model, technicalSpecifications, material;
    double price;
    int quantity;
    float warranty;

    std::cout << "\nEnter details for a new Clothing item:\n";
    std::cout << "Name: ";
    std::cin >> name;
    std::cout << "Brand: ";
    std::cin >> brand;
    std::cout << "Price: ";
    std::cin >> price;
    std::cout << "Quantity: ";
    std::cin >> quantity;
    std::cout << "Description: ";
    std::cin.ignore();
    std::getline(std::cin, description);
    std::cout << "Size: ";
    std::cin >> size;
    std::cout << "Color: ";
    std::cin >> color;
    std::cout << "Category: ";
    std::cin >> category;
    std::cout << "Model: ";
    std::cin >> model;
    std::cout << "Warranty (in years): ";
    std::cin >> warranty;
    std::cout << "Material: ";
    std::cin >> material;

    Clothing userShirt(name, brand, price, quantity, description, size, color, category, model, warranty, "", material);

    // Prompting user to input details for Electronics
    std::cout << "\nEnter details for a new Electronics item:\n";
    std::cout << "Name: ";
    std::cin >> name;
    std::cout << "Brand: ";
    std::cin >> brand;
    std::cout << "Price: ";
    std::cin >> price;
    std::cout << "Quantity: ";
    std::cin >> quantity;
    std::cout << "Description: ";
    std::cin.ignore();
    std::getline(std::cin, description);
    std::cout << "Color: ";
    std::cin >> color;
    std::cout << "Category: ";
    std::cin >> category;
    std::cout << "Model: ";
    std::cin >> model;
    std::cout << "Warranty (in years): ";
    std::cin >> warranty;
    std::cout << "Technical Specifications: ";
    std::cin.ignore();
    std::getline(std::cin, technicalSpecifications);

    Electronics userPhone(name, brand, price, quantity, description, "", color, category, model, warranty, technicalSpecifications, "");

    // Printing user-input details
    std::cout << "\n\nUser-defined Clothing Item: " << userShirt.getName() << "\nBrand: " << userShirt.getBrand() << "\nPrice: " << userShirt.getPrice() << "\nQuantity: " << userShirt.getQuantity() << "\nDescription: " << userShirt.getDescription() << "\nSize: " << userShirt.getSize() << "\nColor: " << userShirt.getColor() << "\nCategory: " << userShirt.getCategory() << "\nModel: " << userShirt.getModel() << "\nWarranty: " << userShirt.getWarranty() << " years \nMaterial: " << userShirt.getMaterial() << std::endl;

    std::cout << "\nUser-defined Electronics Item: " << userPhone.getName() << "\nBrand: " << userPhone.getBrand() << "\nPrice: " << userPhone.getPrice() << "\nQuantity: " << userPhone.getQuantity() << "\nDescription: " << userPhone.getDescription() << "\nColor: " << userPhone.getColor() << "\nCategory: " << userPhone.getCategory() << "\nModel: " << userPhone.getModel() << "\nWarranty: " << userPhone.getWarranty() << " years \nTechnical Specifications: " << userPhone.getTechnicalSpecifications() << std::endl;

    return 0;
}

