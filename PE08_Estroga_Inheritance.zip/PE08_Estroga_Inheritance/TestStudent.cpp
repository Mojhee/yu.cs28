// TestStudent.cpp
// Ezra Aneurin Estroga
// Programming Exercise 08 - OOP 4 Inheritance

#include <iostream>
#include "Student.h"

int main() {
    std::string input;

    Student student;

    std::cout << "This program creates a Student Object which has attributes unique to the Student Class as well as those inherited from the Person Class. The data will be inputted by the user (student) and displayed right after.\n\n";
    std::cout << "Programmed by: Ezra Aneurin Aribe Estroga\n\n\n";

    std::cout << "Enter Student First Name: ";
    std::getline(std::cin, input);
    student.setFirstName(input);

    std::cout << "Enter Student Last Name: ";
    std::getline(std::cin, input);
    student.setLastName(input);

    std::cout << "Enter Student Gender: ";
    std::getline(std::cin, input);
    student.setGender(input);

    std::cout << "Enter Student Email: ";
    std::getline(std::cin, input);
    student.setEmail(input);

    std::cout << "Enter Student Cellphone Number: ";
    std::getline(std::cin, input);
    student.setCpNumber(input);

    std::cout << "Enter Student Number: ";
    std::getline(std::cin, input);
    student.setStudentNum(input);

    std::cout << "Enter Course: ";
    std::getline(std::cin, input);
    student.setCourse(input);

    std::cout << "Enter Department: ";
    std::getline(std::cin, input);
    student.setDepartment(input);

    std::cout << "Enter College: ";
    std::getline(std::cin, input);
    student.setCollege(input);

    std::cout << "\nStudent Details:\n";
    std::cout << "First Name: " << student.getFirstName() << "\n";
    std::cout << "Last Name: " << student.getLastName() << "\n";
    std::cout << "Gender: " << student.getGender() << "\n";
    std::cout << "Email: " << student.getEmail() << "\n";
    std::cout << "Cellphone Number: " << student.getCpNumber() << "\n";
    std::cout << "Student Number: " << student.getStudentNum() << "\n";
    std::cout << "Course: " << student.getCourse() << "\n";
    std::cout << "Department: " << student.getDepartment() << "\n";
    std::cout << "College: " << student.getCollege() << "\n\n";

    std::cout << "Congratulations, " << student.getFirstName() << " " << student.getLastName() << "! \n\nWelcome to the University of the Philippines-Mindanao! \nWe are pleased to inform you that you are admitted in the " 
              << student.getCourse() << " program under the Department of " << student.getDepartment() 
              << ", College of " << student.getCollege() << ". \nYour Student number is " << student.getStudentNum() << ".\n\n"
			  << "We are delighted to have you in our university. We hope to see you around, God bless!\n";

    return 0;
}

