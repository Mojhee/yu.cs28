// TestEmployees.cpp
// Ezra Aneurin Estroga
// Programming Exercise 08 - OOP 4 Inheritance

#include <iostream>
#include "Employees.h"

int main() {
    std::string input;
    double salary;

    Employees employee;

    std::cout << "This program creates an Employees Object which has attributes unique to the Employees Class as well as those inherited from the Person Class. The data will be inputted by the user (employee) and displayed right after.\n\n";
    std::cout << "Programmed by: Ezra Aneurin Aribe Estroga\n\n\n";

    std::cout << "Enter Employee First Name: ";
    std::getline(std::cin, input);
    employee.setFirstName(input);

    std::cout << "Enter Employee Last Name: ";
    std::getline(std::cin, input);
    employee.setLastName(input);

    std::cout << "Enter Employee Gender: ";
    std::getline(std::cin, input);
    employee.setGender(input);

    std::cout << "Enter Employee Email: ";
    std::getline(std::cin, input);
    employee.setEmail(input);

    std::cout << "Enter Employee Cellphone Number: ";
    std::getline(std::cin, input);
    employee.setCpNumber(input);

    std::cout << "Enter Employee Number: ";
    std::getline(std::cin, input);
    employee.setEmpNum(input);

    std::cout << "Enter Position: ";
    std::getline(std::cin, input);
    employee.setPosition(input);

    std::cout << "Enter Office: ";
    std::getline(std::cin, input);
    employee.setOffice(input);

    std::cout << "Enter Salary: ";
    std::cin >> salary;
    employee.setSalary(salary);

    std::cout << "\nEmployee Details:\n";
    std::cout << "First Name: " << employee.getFirstName() << "\n";
    std::cout << "Last Name: " << employee.getLastName() << "\n";
    std::cout << "Gender: " << employee.getGender() << "\n";
    std::cout << "Email: " << employee.getEmail() << "\n";
    std::cout << "Cellphone Number: " << employee.getCpNumber() << "\n";
    std::cout << "Employee Number: " << employee.getEmpNum() << "\n";
    std::cout << "Position: " << employee.getPosition() << "\n";
    std::cout << "Office: " << employee.getOffice() << "\n";
    std::cout << "Salary: " << employee.getSalary() << "\n";

    std::cout << "\nCongratulations, Sir/Ms " << employee.getFirstName() << " " << employee.getLastName() << "!\n"
              << "You are accepted to work in " << employee.getOffice() << " as " << employee.getPosition()  
              << " with a salary of " << employee.getSalary() << ".\nYour Employee number is " << employee.getEmpNum() << ".\n\n"
			  << "We are looking forward to work with you. God bless.\n";;

    return 0;
}

