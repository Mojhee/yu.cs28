// Person.h
// Ezra Aneurin Estroga
// Programming Exercise 08 - OOP 4 Inheritance

#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
private:
    std::string fname;
    std::string lname;
    std::string gender;

public:
    std::string emailAdd;
    std::string cpNumber;

    // Constructors
    Person() {}
    Person(std::string firstName, std::string lastName, std::string gen)
        : fname(firstName), lname(lastName), gender(gen) {}

    // Set methods
    void setFirstName(std::string firstName) {
        fname = firstName;
    }

    void setLastName(std::string lastName) {
        lname = lastName;
    }

    void setGender(std::string gen) {
        gender = gen;
    }

    void setEmail(std::string email) {
        emailAdd = email;
    }

    void setCpNumber(std::string cp) {
        cpNumber = cp;
    }

    // Get methods
    std::string getFirstName() const {
        return fname;
    }

    std::string getLastName() const {
        return lname;
    }

    std::string getGender() const {
        return gender;
    }

    std::string getEmail() const {
        return emailAdd;
    }

    std::string getCpNumber() const {
        return cpNumber;
    }
};

#endif // PERSON_H

