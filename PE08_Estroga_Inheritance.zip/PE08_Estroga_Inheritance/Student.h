// Student.h
// Ezra Aneurin Estroga
// Programming Exercise 08 - OOP 4 Inheritance

#ifndef STUDENT_H
#define STUDENT_H

#include "Person.h"

class Student : public Person {
private:
    std::string studentNum;

public:
    std::string Course;
    std::string Department;
    std::string College;

    // Set methods
    void setStudentNum(std::string sNum) {
        studentNum = sNum;
    }

    void setCourse(std::string course) {
        Course = course;
    }

    void setDepartment(std::string dept) {
        Department = dept;
    }

    void setCollege(std::string college) {
        College = college;
    }

    // Get methods
    std::string getStudentNum() const {
        return studentNum;
    }

    std::string getCourse() const {
        return Course;
    }

    std::string getDepartment() const {
        return Department;
    }

    std::string getCollege() const {
        return College;
    }
};

#endif // STUDENT_H

