// Employees.h
// Ezra Aneurin Estroga
// Programming Exercise 08 - OOP 4 Inheritance

#ifndef EMPLOYEES_H
#define EMPLOYEES_H

#include "Person.h"

class Employees : public Person {
private:
    std::string empNum;

public:
    std::string Position;
    std::string Office;
    double Salary;

    // Set methods
    void setEmpNum(std::string eNum) {
        empNum = eNum;
    }

    void setPosition(std::string position) {
        Position = position;
    }

    void setOffice(std::string office) {
        Office = office;
    }

    void setSalary(double salary) {
        Salary = salary;
    }

    // Get methods
    std::string getEmpNum() const {
        return empNum;
    }

    std::string getPosition() const {
        return Position;
    }

    std::string getOffice() const {
        return Office;
    }

    double getSalary() const {
        return Salary;
    }
};

#endif // EMPLOYEES_H

