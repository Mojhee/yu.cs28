// Ezra Aneurin Estroga
// Programming Exercise 06 - OOP 2 Activity 3
// May 19, 2024
// Main cpp

#include <iostream>
#include <vector>
#include "Movie.h"
#include "Person.h"

using namespace std;

int main() {
    cout << "The C++ program collects and displays information about a movie. The user will be prompted to input the movie's title, synopsis, MPAA rating, genres, directors, and actors. The information will be stored in data structures and then displayed in the instructed formatted output.\n" << endl;
    cout << "Programmed by: Ezra Aneurin Estroga \n" << endl;

    string movieTitle, movieSynopsis, mpaaRating;
    vector<string> movieGenres;
    vector<Person> movieDirectors;
    vector<Person> movieActors;

    string genre, directorFName, directorLName, directorGender;
    string actorFName, actorLName, actorGender;
    char choice;

    cout << "\nEnter Movie Title: ";
    getline(cin, movieTitle);

    cout << "\nEnter Synopsis: ";
    getline(cin, movieSynopsis);

    cout << "\nWhat is its MPAA Rating: ";
    getline(cin, mpaaRating);

    // Input genres
    do {
        cout << "\nEnter a Genre: ";
        getline(cin, genre);
        movieGenres.push_back(genre);
        cout << "Add another genre? (y/n): ";
        cin >> choice;
        cin.ignore();
    } while (choice == 'y' || choice == 'Y');

    // Input directors
    do {
        cout << "\nEnter Director (First_Name Last_Name Gender): ";
        cin >> directorFName >> directorLName >> directorGender;
        movieDirectors.push_back(Person(directorFName, directorLName, directorGender));
        cout << "Add another director? (y/n): ";
        cin >> choice;
        cin.ignore();
    } while (choice == 'y' || choice == 'Y');

    // Input actors
    do {
        cout << "\nEnter Actor/Actress (First_Name Last_Name Gender): ";
        cin >> actorFName >> actorLName >> actorGender;
        movieActors.push_back(Person(actorFName, actorLName, actorGender));
        cout << "Add another actor/actress? (y/n): ";
        cin >> choice;
        cin.ignore();
    } while (choice == 'y' || choice == 'Y');

    // Create a movie object
    Movie movie(movieTitle, movieSynopsis, mpaaRating, movieGenres, movieDirectors, movieActors);

    // Display movie details
    cout << "\n\nMOVIE DETAILS" << endl;
    cout << "\nMovie Title: " << movie.getTitle() << endl;
    cout << "\nSynopsis: " << movie.getSynopsis() << endl;
    cout << "\nMPAA Rating: " << movie.getRating() << endl;

    cout << "\nGenres: ";
    for (const auto& g : movie.getGenres()) {
        cout << "\n" << g;
    }
    cout << endl;

    cout << "\nDirectors: ";
    for (const auto& d : movie.getDirectors()) {
        cout << "\n" << d.getFirstName() << " " << d.getLastName() << " (" << d.getGender() << ") ";
    }
    cout << endl;

    cout << "\nActors/Actresses: ";
    for (const auto& a : movie.getActors()) {
        cout << "\n" << a.getFirstName() << " " << a.getLastName() << " (" << a.getGender() << ") ";
    }
    cout << endl;

    return 0;
}

