// Ezra Aneurin Estroga
// Programming Exercise 06 - OOP 2 Activity 3
// May 19, 2024
// Movie

#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include <vector>
#include "Person.h"

class Movie {
private:
    std::string title;
    std::string synopsis;
    std::string rating;
    std::vector<std::string> genres;
    std::vector<Person> directors;
    std::vector<Person> actors;

public:
    // Constructors
    Movie() {}
    Movie(std::string movieTitle, std::string movieSynopsis, std::string mpaaRating, std::vector<std::string> movieGenres, std::vector<Person> movieDirectors, std::vector<Person> movieActors)
        : title(movieTitle), synopsis(movieSynopsis), rating(mpaaRating), genres(movieGenres), directors(movieDirectors), actors(movieActors) {}

    // Set methods
    void setTitle(std::string movieTitle) {
        title = movieTitle;
    }

    void setSynopsis(std::string movieSynopsis) {
        synopsis = movieSynopsis;
    }

    void setRating(std::string mpaaRating) {
        rating = mpaaRating;
    }

    void setGenres(std::vector<std::string> movieGenres) {
        genres = movieGenres;
    }

    void setDirectors(std::vector<Person> movieDirectors) {
        directors = movieDirectors;
    }

    void setActors(std::vector<Person> movieActors) {
        actors = movieActors;
    }

    // Get methods
    std::string getTitle() const {
        return title;
    }

    std::string getSynopsis() const {
        return synopsis;
    }

    std::string getRating() const {
        return rating;
    }

    std::vector<std::string> getGenres() const {
        return genres;
    }

    std::vector<Person> getDirectors() const {
        return directors;
    }

    std::vector<Person> getActors() const {
        return actors;
    }
};

#endif // MOVIE_H

