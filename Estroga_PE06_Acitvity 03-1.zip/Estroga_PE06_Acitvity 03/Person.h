// Ezra Aneurin Estroga
// Programming Exercise 06 - OOP 2 Activity 3
// May 19, 2024
// Person

#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
private:
    std::string fname;
    std::string lname;
    std::string gender;

public:
    // Constructors
    Person() {}
    Person(std::string firstName, std::string lastName, std::string gen)
        : fname(firstName), lname(lastName), gender(gen) {}

    // Set methods
    void setFirstName(std::string firstName) {
        fname = firstName;
    }

    void setLastName(std::string lastName) {
        lname = lastName;
    }

    void setGender(std::string gen) {
        gender = gen;
    }

    // Get methods
    std::string getFirstName() const {
        return fname;
    }

    std::string getLastName() const {
        return lname;
    }

    std::string getGender() const {
        return gender;
    }
};

#endif // PERSON_H

