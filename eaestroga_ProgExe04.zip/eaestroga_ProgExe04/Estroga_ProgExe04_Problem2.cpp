#include <iostream>
#include <vector>
using namespace std;

// Function to display program description
void progdescription() {
    cout << "Program Description:\n";
    cout << "This program converts a decimal number to its binary equivalent.\n";
    cout << "Programmer: Ezra Aneurin Aribe Estroga\n";
    cout << "Date: April 25, 2024\n";
    cout << "Subject Number: CMSC 28\n\n";
}

// Function to read input decimal number
int readdata() {
    int num;
    cout << "Enter an integer: ";
    cin >> num;
    return num;
}

// Function to convert decimal to binary
vector<int> decToBinary(int num) {
    vector<int> binary;
    while (num > 0) {
        binary.insert(binary.begin(), num % 2);
        num /= 2;
    }
    return binary;
}

// Function to display binary equivalent
void showdata(int decimal, const vector<int>& binary) {
    cout << "\nDecimal Number: " << decimal << endl;
    cout << "Binary Equivalent: ";
    for (int digit : binary)
        cout << digit;
    cout << endl;
}

int main() {
    progdescription();

    int decimal = readdata();
    vector<int> binary = decToBinary(decimal);

    showdata(decimal, binary);

    return 0;
}

