#include <iostream>
using namespace std;

// Function to display program description
void progdescription() {
    cout << "Program Description:\n";
    cout << "This program finds the highest and lowest numbers from a set of three numbers and then calculates the difference between them.\n";
    cout << "Programmer: Ezra Aneurin Aribe Estroga\n";
    cout << "Date: April 25, 2024\n";
    cout << "Subject Number: CMSC 28\n\n";
}

// Function to read input values
void readdata(int& x, int& y, int& z) {
    cout << "Enter three numbers (x, y, z): ";
    cin >> x >> y >> z;
}

// Function to find the highest number
int getlarge(int x, int y, int z) {
    int largest = x;
    if (y > largest) largest = y;
    if (z > largest) largest = z;
    return largest;
}

// Function to find the lowest number
int getsmall(int x, int y, int z) {
    int smallest = x;
    if (y < smallest) smallest = y;
    if (z < smallest) smallest = z;
    return smallest;
}

// Function to display results
void showdata(int x, int y, int z, int largeval, int smallval, int diff) {
    cout << "\nInputted Numbers:\n";
    cout << "x: " << x << endl;
    cout << "y: " << y << endl;
    cout << "z: " << z << endl;
    cout << "Highest Value: " << largeval << endl;
    cout << "Smallest Value: " << smallval << endl;
    cout << "Difference: " << diff << endl;
}

int main() {
    int x, y, z, smallval, largeval, diff;

    progdescription();

    readdata(x, y, z);

    smallval = getsmall(x, y, z);
    largeval = getlarge(x, y, z);
    diff = largeval - smallval;

    showdata(x, y, z, largeval, smallval, diff);

    return 0;
}

