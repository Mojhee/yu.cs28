// Ezra Aneurin Estroga
// BSCS 1 | CMSC 28
// LAB 06 | Activity 2
// Header Person

// File Name : Person.h

#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>

using namespace std;

class Person {
	private:
	    int age;
	    char gender;
	
	public:
	    // Default constructor
	    Person() : age(0), gender('M') {}
	
	    // Constructor with age
	    Person(int newage) : age(newage), gender('M') {}
	
	    // Constructor with age and gender
	    Person(int newage, char c) : age(newage), gender(c) {}
	
	    // Setter for age
    void setage(int newage) {
        if (newage >= 0) {
            age = newage;
        } else {
            cout << "Invalid age!!!" << endl;
        }
    }

    // Getter for age
    int getage() const {
        return age;
    }

    // Setter for gender
    void setgender(char c) {
        if (c == 'M' || c == 'F') {
            gender = c;
        } else {
            cout << "Invalid gender!!!" << endl;
        }
    }

    // Getter for gender
    char getgender() const {
        return gender;
    }

    // Method to determine the generation based on age
    string getgeneration(age) {
        int birthYear = 2024 - age;
        string generation;

        if (birthYear >= 1901 && birthYear <= 1927) {
            generation = "Greatest Generation";
        } else if (birthYear >= 1928 && birthYear <= 1945) {
            generation = "Silent Generation";
        } else if (birthYear >= 1946 && birthYear <= 1964) {
            generation = "Boomers";
        } else if (birthYear >= 1965 && birthYear <= 1980) {
            generation = "Generation X";
        } else if (birthYear >= 1981 && birthYear <= 1996) {
            generation = "Millennials";
        } else if (birthYear >= 1997 && birthYear <= 2010) {
            generation = "Gen Z";
        } else if (birthYear >= 2011 && birthYear <= 2023) {
            generation = "Generation Alpha";
        } else {
            generation = "Unknown Generation";
        }

        return generation;
    }
};

#endif // PERSON_H

