// Ezra Aneurin Estroga
// BSCS 1 | CMSC 28
// LAB 06 | Activity 1.2
// Header

#ifndef GLASSES_H
#define GLASSES_H

#include <string>
#include <iostream>

class Glasses {
private:
    std::string brand;
    std::string frame;
    std::string lens;

public:
    // Constructor
    Glasses(std::string glbrand, std::string glframe, std::string gllens)
        : brand(glbrand), frame(glframe), lens(gllens) {}

    // Method to display the glass details
    void display() const {
        std::cout << "Brand: " << brand << std::endl;
        std::cout << "Frame: " << frame << std::endl;
        std::cout << "Lens: " << lens << std::endl;
    }
};

#endif // GLASSES_H

