// Ezra Aneurin Estroga
// BSCS 1 | CMSC 28
// LAB 06 | Activity 2
// Header Name

#ifndef NAME_H
#define NAME_H

#include <iostream>
#include <string>

using namespace std;

class Name {
private:
    string firstName;
    string lastName;

public:
    // Constructor with parameters
    Name(const string& fname, const string& lname)
        : firstName(fname), lastName(lname) {}

    // Setter for first name
    void setFirstName(const string& fname) {
        firstName = fname;
    }

    // Getter for first name
    string getFirstName() const {
        return firstName;
    }

    // Setter for last name
    void setLastName(const string& lname) {
        lastName = lname;
    }

    // Getter for last name
    string getLastName() const {
        return lastName;
    }

    // Method to display the full name
    void view() const {
        cout << "First Name: " << firstName << endl;
        cout << "Last Name: " << lastName << endl;
    }
};

#endif // NAME_H

