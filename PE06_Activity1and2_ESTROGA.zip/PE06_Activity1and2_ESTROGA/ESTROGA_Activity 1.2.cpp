// Ezra Aneurin Estroga
// BSCS 1 | CMSC 28
// LAB 06 | Activity 1.2
// Main

#include "glasses.h"

int main() {
    // Create an object of Glasses
    Glasses myGlasses("Prada", "Metal", "Polarized");

    // Display the details of the glasses
    myGlasses.display();

    return 0;
}

