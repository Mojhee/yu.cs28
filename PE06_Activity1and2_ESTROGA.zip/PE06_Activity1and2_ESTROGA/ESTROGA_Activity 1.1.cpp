// Ezra Aneurin Estroga
// BSCS 1 | CMSC 28
// LAB 06 | Activity 1.1

#include <iostream>
#include <string>

class Glasses {
private:
    std::string brand;
    std::string frame;
    std::string lens;

public:
    // Constructor
    Glasses(std::string glbrand, std::string glframe, std::string gllens)
        : brand(glbrand), frame(glframe), lens(gllens) {}

    // Method to display the glass details
    void display() const {
        std::cout << "Brand: " << brand << std::endl;
        std::cout << "Frame: " << frame << std::endl;
        std::cout << "Lens: " << lens << std::endl;
    }
};

int main() {
    // Create an object of Glasses
    Glasses myGlasses("Prada", "Metal", "Polarized");

    // Display the details of the glasses
    myGlasses.display();

    return 0;
}

