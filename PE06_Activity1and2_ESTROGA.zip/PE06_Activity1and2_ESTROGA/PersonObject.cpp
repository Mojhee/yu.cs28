// Ezra Aneurin Estroga
// BSCS 1 | CMSC 28
// LAB 06 | Activity 2
// Main Function

#include <iostream>
#include <string>
#include "Person.h"
#include "Name.h"

using namespace std;

int main() {
    int age;
    char gender;
    string firstName, lastName;

    cout << "Creating the Person Object" << endl;
    Person p;

    cout << "\nInput age: ";
    cin >> age;
    p.setage(age);

    cout << "Input gender (M/F): ";
    cin >> gender;
    p.setgender(gender);

    cout << "\nCreating the Name Object" << endl;

    cout << "\nInput first name: ";
    cin >> firstName;

    cout << "Input last name: ";
    cin >> lastName;

    Name n(firstName, lastName);

    cout << "\n\nPerson details:" << endl;
    cout << "Person first name is = " << n.getFirstName() << endl;
    cout << "Person last name is = " << n.getLastName() << endl;
    cout << "Person age is = " << p.getage() << endl;
    cout << "Person gender is = " << p.getgender() << endl;
    cout << "Person belongs to = " << p.getgeneration() << endl;

    return 0;
}

